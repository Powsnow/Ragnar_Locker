# Noroff University College - LaTeX for final degree project reports.

This class is intended to be used for the production of Final Degree projects at Noroff University College.

A copy of the template is available on Overleaf: https://www.overleaf.com/read/pwjjtgttbbbq
A GitHub repository maintians current version: https://github.com/barryirwin/Uc3FDP201-2020-template/

This class extends the standard report class.

## Usage
The sample main.tex provided a minimalist use of the nucthesis class.  

Users should be aware that they should remove a number of the guidance blocks (\guidence*) from the code once they have read them. These are there to provide some guidance about what should go in the sections.


YMMV.
